package com.cg.jpastart.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="distance_calculator")
public class Distance implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int distanceId;
	private String source;
	private String destination;
	private double distanceKm;
	private double distanceM;
	public int getDistanceId() {
		return distanceId;
	}
	public void setDistanceId(int distanceId) {
		this.distanceId = distanceId;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public double getDistanceKm() {
		return distanceKm;
	}
	public void setDistanceKm(double distanceKm) {
		this.distanceKm = distanceKm;
	}
	public double getDistanceM() {
		return distanceM;
	}
	public void setDistanceM(double distanceM) {
		this.distanceM = distanceM;
	}

}
